# iNWEB-WMS — PROJECT GOVERNANCE

| Field | Value |
|---|---|
| Document | PROJECT_GOVERNANCE.md |
| Version | 1.0.0 |
| Status | Proposed |
| Organization | iNAYATechLab Pvt. Ltd. |
| Project Owner | YourSamiBD |
| GitHub Organization | iNWEB-Official |
| Repository | iNWEB-WMS |

## Purpose

This document is the root governance reference for iNWEB-WMS. Detailed project
rules and policies are maintained in [`docs/governance/`](./docs/governance/).

## Scope

- Project rules and policies: `docs/governance/`
- Requirements (SRS / business): `docs/requirements/`
- Architecture & decisions (ADRs): `docs/architecture/`, `docs/decisions/`
- Security policies: `docs/security/`
- Testing standards: `docs/testing/`
- Deployment instructions: `docs/deployment/`

## Structural Governance

1. The authoritative repository layout is defined in
   [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md).
2. All structural changes must be documented and reviewed before merging.
3. Sensitive credentials must never be committed.
4. Environment variables must follow the documented configuration
   (`.env.example`).

> Detailed governance content is to be defined and approved by the Project Owner.
