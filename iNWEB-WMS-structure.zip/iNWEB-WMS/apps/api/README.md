# @inweb/api

Backend API for iNWEB-WMS. Modules live in `src/modules/`, cross-cutting
concerns (decorators, guards, interceptors, filters, middleware, validators)
in `src/common/`. See `../../PROJECT_STRUCTURE.md` (§4).
