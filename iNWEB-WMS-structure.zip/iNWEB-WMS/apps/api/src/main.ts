/**
 * iNWEB-WMS Backend API — entry point.
 * Bootstrap the API server here. Modules live in ./modules,
 * cross-cutting concerns in ./common. See ../../PROJECT_STRUCTURE.md (§4).
 */
export {};
