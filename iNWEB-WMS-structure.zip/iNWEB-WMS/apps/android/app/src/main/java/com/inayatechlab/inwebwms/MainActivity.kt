package com.inayatechlab.inwebwms

/**
 * iNWEB-WMS Android — main entry point.
 * Features live in ./features, core concerns in ./core.
 * Android uses native Kotlin models and API contracts (PROJECT_STRUCTURE.md §6).
 */
class MainActivity {
    // TODO: extend the chosen Android activity base class during app setup.
}
