// Top-level build file — plugin versions and shared configuration live here.
// See ../../PROJECT_STRUCTURE.md (§5).
