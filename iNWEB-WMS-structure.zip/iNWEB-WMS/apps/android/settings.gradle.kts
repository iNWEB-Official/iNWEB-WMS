rootProject.name = "iNWEB-WMS"
include(":app")
