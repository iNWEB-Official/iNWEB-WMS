# iNWEB-WMS Android

Native Android application (Kotlin), package `com.inayatechlab.inwebwms`.
See `../../PROJECT_STRUCTURE.md` (§5). Android uses native Kotlin models and
API contracts rather than importing TypeScript packages (§6).
