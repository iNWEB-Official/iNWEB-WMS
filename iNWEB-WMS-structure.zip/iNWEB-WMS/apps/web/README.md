# @inweb/web

Next.js web application for iNWEB-WMS. See `../../PROJECT_STRUCTURE.md` (§3)
for the folder layout. Business logic belongs in `src/features/` and
`src/services/` — not mixed into UI components.
