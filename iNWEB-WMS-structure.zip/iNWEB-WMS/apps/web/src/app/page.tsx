export default function HomePage() {
  return (
    <main>
      <h1>iNWEB-WMS</h1>
      <p>Workforce Management System — web application scaffold.</p>
    </main>
  );
}
