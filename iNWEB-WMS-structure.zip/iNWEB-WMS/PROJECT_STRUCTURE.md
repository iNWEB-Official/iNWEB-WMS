# iNWEB-WMS — PROJECT STRUCTURE

| Field | Value |
|---|---|
| Document | PROJECT_STRUCTURE.md |
| Version | 1.0.0 |
| Status | Proposed |
| Organization | iNAYATechLab Pvt. Ltd. |
| Project Owner | YourSamiBD |
| GitHub Organization | iNWEB-Official |
| Repository | iNWEB-WMS |

## 1. Repository Architecture

**Architecture:** Monorepo

The repository contains the complete Web, Backend, Android, Shared Packages,
Documentation, Testing and Infrastructure components.

## 2. Root Folder Structure

```text
iNWEB-WMS/
├── apps/
│   ├── web/
│   ├── api/
│   └── android/
├── packages/
│   ├── shared-types/
│   ├── shared-utils/
│   ├── validation/
│   ├── api-client/
│   └── config/
├── docs/
│   ├── governance/
│   ├── requirements/
│   ├── architecture/
│   ├── database/
│   ├── ui-ux/
│   ├── api/
│   ├── security/
│   ├── testing/
│   ├── deployment/
│   ├── reports/
│   └── decisions/
├── infrastructure/
│   ├── docker/
│   ├── database/
│   ├── deployment/
│   ├── monitoring/
│   └── backup/
├── scripts/
├── tests/
│   ├── integration/
│   ├── e2e/
│   ├── security/
│   └── performance/
├── .github/
│   ├── workflows/
│   ├── ISSUE_TEMPLATE/
│   └── PULL_REQUEST_TEMPLATE/
├── .editorconfig
├── .gitignore
├── .gitattributes
├── .env.example
├── package.json
├── pnpm-workspace.yaml
├── turbo.json
├── README.md
├── PROJECT_GOVERNANCE.md
└── PROJECT_STRUCTURE.md
```

## 3. Web Application

Location: `apps/web/`

```text
web/
├── public/
│   ├── images/
│   ├── icons/
│   └── fonts/
├── src/
│   ├── app/
│   │   ├── (auth)/
│   │   ├── (dashboard)/
│   │   ├── employees/
│   │   ├── attendance/
│   │   ├── leave/
│   │   ├── expenses/
│   │   ├── finance/
│   │   ├── payroll/
│   │   ├── sites/
│   │   ├── documents/
│   │   ├── complaints/
│   │   ├── accommodation/
│   │   ├── notices/
│   │   ├── reports/
│   │   ├── settings/
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/
│   │   ├── ui/
│   │   ├── layout/
│   │   ├── dashboard/
│   │   ├── forms/
│   │   ├── tables/
│   │   └── charts/
│   ├── features/
│   │   ├── employees/
│   │   ├── attendance/
│   │   ├── leave/
│   │   ├── expenses/
│   │   ├── finance/
│   │   ├── payroll/
│   │   ├── sites/
│   │   ├── documents/
│   │   └── reports/
│   ├── hooks/
│   ├── lib/
│   ├── services/
│   ├── stores/
│   ├── types/
│   ├── i18n/
│   └── styles/
├── tests/
├── next.config.ts
├── package.json
└── tsconfig.json
```

## 4. Backend API

Location: `apps/api/`

```text
api/
├── src/
│   ├── modules/
│   │   ├── auth/
│   │   ├── users/
│   │   ├── employees/
│   │   ├── attendance/
│   │   ├── leave/
│   │   ├── expenses/
│   │   ├── finance/
│   │   ├── payroll/
│   │   ├── companies/
│   │   ├── sites/
│   │   ├── documents/
│   │   ├── complaints/
│   │   ├── accommodation/
│   │   ├── notifications/
│   │   ├── reports/
│   │   └── audit-logs/
│   ├── common/
│   │   ├── decorators/
│   │   ├── guards/
│   │   ├── interceptors/
│   │   ├── filters/
│   │   ├── middleware/
│   │   └── validators/
│   ├── database/
│   ├── config/
│   ├── integrations/
│   ├── storage/
│   ├── health/
│   └── main.ts
├── test/
├── package.json
└── tsconfig.json
```

## 5. Android Application

Location: `apps/android/`

```text
android/
├── app/
│   └── src/
│       ├── main/
│       │   ├── java/
│       │   │   └── com/inayatechlab/inwebwms/
│       │   │       ├── core/
│       │   │       │   ├── network/
│       │   │       │   ├── database/
│       │   │       │   ├── security/
│       │   │       │   └── common/
│       │   │       ├── data/
│       │   │       ├── domain/
│       │   │       ├── navigation/
│       │   │       ├── ui/
│       │   │       ├── features/
│       │   │       │   ├── authentication/
│       │   │       │   ├── dashboard/
│       │   │       │   ├── attendance/
│       │   │       │   ├── leave/
│       │   │       │   ├── expenses/
│       │   │       │   ├── employees/
│       │   │       │   ├── notifications/
│       │   │       │   └── profile/
│       │   │       └── MainActivity.kt
│       │   ├── res/
│       │   └── AndroidManifest.xml
│       ├── test/
│       └── androidTest/
├── gradle/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## 6. Shared Packages

Location: `packages/`

| Package | Responsibility |
|---|---|
| shared-types | Shared TypeScript types |
| shared-utils | Common utility functions |
| validation | Data validation schemas |
| api-client | API communication |
| config | Shared development configuration |

Android will use its native Kotlin models and API contracts rather than
importing TypeScript packages.

## 7. Documentation Structure

Location: `docs/`

| Directory | Contents |
|---|---|
| governance/ | Project rules and policies |
| requirements/ | SRS and business requirements |
| architecture/ | System architecture |
| database/ | Database design |
| ui-ux/ | UI/UX specifications |
| api/ | API documentation |
| security/ | Security policies |
| testing/ | Testing standards |
| deployment/ | Deployment instructions |
| reports/ | Development reports |
| decisions/ | Architecture Decision Records |

## 8. Infrastructure

Location: `infrastructure/`

- Docker configuration
- Database initialization
- Database migration support
- Deployment configurations
- Monitoring
- Backup and recovery

## 9. Testing Structure

Testing must cover:

- Unit tests
- Integration tests
- End-to-end tests
- API tests
- Security tests
- Performance tests
- Android UI tests

## 10. Folder Structure Rules

1. Every application must maintain clear module separation.
2. Business logic must not be unnecessarily mixed with UI components.
3. Shared functionality must be placed in appropriate shared packages.
4. Sensitive credentials must never be committed.
5. Environment variables must use documented configuration.
6. Tests must remain organized.
7. Documentation must be maintained alongside implementation.
8. Every new major module must follow established naming conventions.
9. Avoid unnecessary folders and duplicate implementations.
10. All structural changes must be documented and reviewed.

---

> Document Report: PROJECT_STRUCTURE.md | Version 1.0.0 | Status: Proposed |
> Architecture: Monorepo | Applications: Web + Backend API + Android |
> Shared Packages, Documentation, Infrastructure and Testing structures defined.
