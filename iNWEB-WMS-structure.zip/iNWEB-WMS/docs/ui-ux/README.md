# docs/ui-ux

UI/UX specifications for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
