# docs/database

Database design for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
