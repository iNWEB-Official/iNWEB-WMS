# docs/governance

Project rules and policies for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
