# docs/testing

Testing standards for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
