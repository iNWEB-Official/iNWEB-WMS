# docs/architecture

System architecture for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
