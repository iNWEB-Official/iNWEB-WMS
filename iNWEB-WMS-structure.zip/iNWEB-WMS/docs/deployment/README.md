# docs/deployment

Deployment instructions for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
