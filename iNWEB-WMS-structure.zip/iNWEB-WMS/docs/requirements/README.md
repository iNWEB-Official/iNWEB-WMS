# docs/requirements

SRS and business requirements for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§7).
