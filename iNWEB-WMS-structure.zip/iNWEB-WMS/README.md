# iNWEB-WMS

Workforce Management System by **iNAYATechLab Pvt. Ltd.**

| Field | Value |
|---|---|
| Organization | iNAYATechLab Pvt. Ltd. |
| Project Owner | YourSamiBD |
| GitHub Organization | iNWEB-Official |
| Repository | iNWEB-WMS |
| Architecture | Monorepo |
| Structure Document | [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) (v1.0.0, Proposed) |
| Governance | [PROJECT_GOVERNANCE.md](./PROJECT_GOVERNANCE.md) |

## Applications

| App | Location | Description |
|---|---|---|
| Web | `apps/web/` | Next.js web application |
| Backend API | `apps/api/` | Backend API service |
| Android | `apps/android/` | Native Android application (Kotlin) |

## Shared Packages

| Package | Location | Responsibility |
|---|---|---|
| shared-types | `packages/shared-types/` | Shared TypeScript types |
| shared-utils | `packages/shared-utils/` | Common utility functions |
| validation | `packages/validation/` | Data validation schemas |
| api-client | `packages/api-client/` | API communication |
| config | `packages/config/` | Shared development configuration |

> Android uses native Kotlin models and API contracts rather than importing
> TypeScript packages.

## Repository Layout

See [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) for the full, authoritative
folder structure, and `docs/` for governance, requirements, architecture,
database, UI/UX, API, security, testing, deployment, reports and decisions
(ADRs).

## Getting Started

Prerequisites: Node.js 20+, pnpm, JDK + Android Studio (for Android).

```bash
pnpm install
cp .env.example .env   # fill in local values — never commit real secrets
pnpm dev
```

## Rules

- Never commit sensitive credentials; use documented environment variables.
- Keep business logic separate from UI components.
- Put shared functionality in the appropriate shared package.
- Maintain documentation alongside implementation.
- All structural changes must be documented and reviewed.
