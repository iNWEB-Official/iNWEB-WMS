---
name: Bug report
about: Report a bug in iNWEB-WMS
labels: bug
---

## Description

## Steps to reproduce

## Expected / actual behaviour

## Environment
