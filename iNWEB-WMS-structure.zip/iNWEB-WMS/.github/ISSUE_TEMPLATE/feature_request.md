---
name: Feature request
about: Propose a new feature for iNWEB-WMS
labels: enhancement
---

## Problem / motivation

## Proposed solution

## Alternatives considered
