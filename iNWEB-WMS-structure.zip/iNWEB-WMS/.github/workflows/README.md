# workflows

GitHub Actions workflows for iNWEB-WMS (CI to be defined).
