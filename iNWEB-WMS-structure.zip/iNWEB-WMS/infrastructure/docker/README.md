# infrastructure/docker

Docker configuration for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§8).
