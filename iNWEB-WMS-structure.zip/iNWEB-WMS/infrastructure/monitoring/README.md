# infrastructure/monitoring

Monitoring for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§8).
