# infrastructure/deployment

Deployment configurations for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§8).
