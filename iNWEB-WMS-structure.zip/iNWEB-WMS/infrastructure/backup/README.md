# infrastructure/backup

Backup and recovery for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§8).
