# infrastructure/database

Database initialization and migration support for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§8).
