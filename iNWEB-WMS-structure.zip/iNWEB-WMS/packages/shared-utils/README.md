# @inweb/shared-utils

Common utility functions for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§6).
