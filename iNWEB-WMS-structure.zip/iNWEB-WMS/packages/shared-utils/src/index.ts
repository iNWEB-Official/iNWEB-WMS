/**
 * @inweb/shared-utils — Common utility functions.
 * See ../../../PROJECT_STRUCTURE.md (§6).
 */
export {};
