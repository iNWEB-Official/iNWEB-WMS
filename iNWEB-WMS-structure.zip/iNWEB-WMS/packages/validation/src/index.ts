/**
 * @inweb/validation — Data validation schemas.
 * See ../../../PROJECT_STRUCTURE.md (§6).
 */
export {};
