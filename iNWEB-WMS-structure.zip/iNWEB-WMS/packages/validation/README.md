# @inweb/validation

Data validation schemas for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§6).
