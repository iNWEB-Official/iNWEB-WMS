/**
 * @inweb/api-client — API communication.
 * See ../../../PROJECT_STRUCTURE.md (§6).
 */
export {};
