# @inweb/api-client

API communication for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§6).
