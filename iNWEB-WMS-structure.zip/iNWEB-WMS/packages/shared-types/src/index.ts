/**
 * @inweb/shared-types — Shared TypeScript types.
 * See ../../../PROJECT_STRUCTURE.md (§6).
 */
export {};
