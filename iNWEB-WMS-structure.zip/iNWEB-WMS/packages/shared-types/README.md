# @inweb/shared-types

Shared TypeScript types for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§6).
