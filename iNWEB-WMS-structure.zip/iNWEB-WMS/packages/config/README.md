# @inweb/config

Shared development configuration for iNWEB-WMS. See `../../../PROJECT_STRUCTURE.md` (§6).
