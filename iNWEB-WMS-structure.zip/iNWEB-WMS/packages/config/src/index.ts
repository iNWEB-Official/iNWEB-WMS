/**
 * @inweb/config — Shared development configuration.
 * See ../../../PROJECT_STRUCTURE.md (§6).
 */
export {};
