# tests

Cross-application test suites (see `../PROJECT_STRUCTURE.md` §9):

- `integration/` — integration & API tests
- `e2e/` — end-to-end tests
- `security/` — security tests
- `performance/` — performance tests

Unit tests live beside each app/package; Android UI tests live in
`apps/android/app/src/androidTest/`.
